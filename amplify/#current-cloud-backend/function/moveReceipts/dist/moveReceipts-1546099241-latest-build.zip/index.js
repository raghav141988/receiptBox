const awsServerlessExpress = require('aws-serverless-express');
const app = require('./app');
const async = require('async');
const server = awsServerlessExpress.createServer(app);

exports.handler = async(event, context,callback) => {
  console.log(`EVENT: ${JSON.stringify(event)}`);
  console.log(`EVENT: ${JSON.stringify(event)}`);
  console.log(callback);

  event.lambdaCallBack=callback;
//   var response = {
//     "statusCode": 200,
//     "headers": {
//         "my_header": "my_value"
//     },
//     "body": JSON.stringify(responseBody),
//     "isBase64Encoded": false
// };

const serverResponse= await new Promise((resolve, reject) => {
 const result= awsServerlessExpress.proxy(server, event, context);
 resolve({
  statusCode: 200,
  result: result
});

});
console.log('Server Response****');
console.log(serverResponse);
  callback(null,{success: 'post call succeed!', url: 'test', data: 'test'});
};
