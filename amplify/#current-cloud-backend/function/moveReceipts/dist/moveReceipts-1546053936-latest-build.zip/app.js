/*
Copyright 2017 - 2017 Amazon.com, Inc. or its affiliates. All Rights Reserved.
Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance with the License. A copy of the License is located at
    http://aws.amazon.com/apache2.0/
or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and limitations under the License.
*/

var express = require('express')
var mime=require('mime-types')
var uuid=require('node-uuid');
var bodyParser = require('body-parser')
var awsServerlessExpressMiddleware = require('aws-serverless-express/middleware')


// declare a new express app
var app = express()
app.use(bodyParser.json())
app.use(awsServerlessExpressMiddleware.eventContext())


const AWS = require('aws-sdk');
const async = require('async');
const bucketName = 'receiptmanagerstorage';
//const oldPrefix = 'abc/';
//const newPrefix = 'xyz/';
const dynamodb = new AWS.DynamoDB.DocumentClient();
let tableName = "Receipts";
const s3 = new AWS.S3({
    apiVersion: '2006-03-01',
     
    region: 'us-east-1'
});

// 1) List all the objects in the source "directory"


// Enable CORS for all methods
app.use(function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*")
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept")
  next()
});


/**********************
 * Example get method *
 **********************/


/****************************
* Example post method *
****************************/
    app.post('/moveReceipts',  function(req, res) {
  // Add your code here
  //GET THE USER SUB HERE
  const oldPrefix = req.apiGateway.event.requestContext.identity.cognitoAuthenticationProvider.split(':CognitoSignIn:')[1]+'/';
  const newPrefix = req.apiGateway.event.requestContext.identity.cognitoIdentityId+'/'
let succeededReceipts=[];
let failedReceipts=[];
let errorObj={}

 console.log('method called moveReceipts');




let paramsS3Delete = {
    Bucket: bucketName,
    Delete: {
        Objects: []
    }
};


async.each(req.body.receipts, function(receipt,cb)  {
    const extension = mime.extension(receipt.contentType);
     const fileName=uuid.v1()+"."+extension;
     const destinationFileName=('public/' + receipt.receiptKey+fileName).replace(oldPrefix,newPrefix).replace('public','private');
    const dbReceiptId=destinationFileName.replace(newPrefix,"");
    console.log('Destination FIle key '+destinationFileName);
    console.log('DB receipt ID '+dbReceiptId);
    
    let params = {
        Bucket: bucketName,
        CopySource: bucketName + '/public/' + receipt.receiptKey,
         Key: destinationFileName
    };
    console.log('file to be copied to');
    console.log(params);
    //CALL S3 COPY
   
    //const result=await s3.copyObject(params);
    s3.copyObject(params,(err,data)=>{
        if(err){
            console.log('Copy Error'+err); 
            failedReceipts.push({
              receipt:receipt,
              error:err
            })
        }else {
              console.log(data);
              console.log('S3 copied successful');
              paramsS3Delete.Delete.Objects.push({
                Key: 'public/'+receipt.receiptKey
            });

            // CALL DYNAMO DB TO UPDATE RECORDS
            const titleCat=receipt.title+"-"+receipt.category;
            const titleCatKey='title-category';
const dbRowData={
    ...receipt,
   // isLatestReceipt:null,
    receiptKey:dbReceiptId.replace('private/',''),
    [titleCatKey]:titleCat,
    userSub:oldPrefix.replace('/',''),
    
}

let putItemParams = {
    TableName: tableName,
    Item: dbRowData
  }
  dynamodb.put(putItemParams, (err, data) => {
    if(err) {
      console.log('DB put failed '+err+' For');
      console.log(receipt);
      failedReceipts.push({
        receipt:receipt,
        error:err
      });

    } else{
        console.log('DB put succeeded for');
        console.log(receipt);
    }
  });


}
    
        cb();
    });
},function (asyncError, asyncData) {
    // All the requests for the file copy have finished
    if (asyncError) {
        
        //TOTAL ERROR
        errorObj = {
          errorType : "InternalServerError",
          httpStatus : 500,
          requestId : context.awsRequestId,
         error:asyncError
      }
      return console.log(asyncError);
    } else {
        console.log(asyncData);
        console.log(paramsS3Delete);
        // 3) Now remove the source files - that way we effectively moved all the content
        s3.deleteObjects(paramsS3Delete, (deleteError, deleteData) => {
            if (deleteError) return console.log(deleteError);
            succeededReceipts.push({
              receipt:{
                ...receipt,
                receiptKey:dbReceiptId.replace('private/','')
              
              },
            
            })
            return console.log(deleteData);
        });

    }
});
   

const finalResult= {
  success: 'Operation successful',
  succeededReceipts:succeededReceipts,
  failedReceipts:failedReceipts
}
if(errorObj){
console.log(errorObj);
res.json({error: errorObj});
}else{
  res.json(finalResult);
}
   

 
});


app.listen(3000, function() {
    console.log("App started");
});

// Export the app object. When executing the application local this does nothing. However,
// to port it to AWS Lambda we will create a wrapper around that will load the app from
// this file
module.exports = app;
