const awsServerlessExpress = require('aws-serverless-express');
const app = require('./app');
const async = require('async');
const server = awsServerlessExpress.createServer(app);

exports.handler = async(event, context) => {
  console.log(`EVENT: ${JSON.stringify(event)}`);
  console.log(`EVENT: ${JSON.stringify(event)}`);
  //console.log(callback);


//   var response = {
//     "statusCode": 200,
//     "headers": {
//         "my_header": "my_value"
//     },
//     "body": JSON.stringify(responseBody),
//     "isBase64Encoded": false
// };

 awsServerlessExpress.proxy(server, event, context);
 
console.log('proxy called****');

 // callback(null,{success: 'post call succeed!', url: 'test', data: 'test'});
};
