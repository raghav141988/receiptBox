const awsServerlessExpress = require('aws-serverless-express');
const app = require('./app');
const async = require('async');
const server = awsServerlessExpress.createServer(app);

exports.handler = async(event, context,callback) => {
  console.log(`EVENT: ${JSON.stringify(event)}`);
  console.log(`EVENT: ${JSON.stringify(event)}`);
  console.log(callback);

  event.lambdaCallBack=callback;
//   var response = {
//     "statusCode": 200,
//     "headers": {
//         "my_header": "my_value"
//     },
//     "body": JSON.stringify(responseBody),
//     "isBase64Encoded": false
// };



  const response= await awsServerlessExpress.proxy(server, event, context);
  console.log('Lamda response***');
  console.log(response);
   // callback(null,response);
};
