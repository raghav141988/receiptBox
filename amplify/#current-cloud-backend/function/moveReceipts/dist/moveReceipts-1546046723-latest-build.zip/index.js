const awsServerlessExpress = require('aws-serverless-express');
const app = require('./app');

const server = awsServerlessExpress.createServer(app);

exports.handler = (event, context,callback) => {
  console.log(`EVENT: ${JSON.stringify(event)}`);
  console.log(`EVENT: ${JSON.stringify(event)}`);
  console.log(callback);
  event.lambdaCallback=callback;
  event.lambdaContext=context;
  callback(null,'its done');
    awsServerlessExpress.proxy(server, event, context);
   
};
